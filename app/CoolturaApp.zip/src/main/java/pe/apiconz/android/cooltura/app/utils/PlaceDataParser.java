package pe.apiconz.android.cooltura.app.utils;

/**
 * Created by Indra on 25/12/2014.
 */
public class PlaceDataParser {


}
